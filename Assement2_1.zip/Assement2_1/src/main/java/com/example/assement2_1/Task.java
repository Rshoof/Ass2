package com.example.assement2_1;


import lombok.AllArgsConstructor;
import lombok.Data;

@Data @AllArgsConstructor
public class Task {
    public String id;
    public String title;
    public String description;
    public String status;
    public String deadline;
}
