package com.example.assement2_1;

import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;

@RestController
@RequestMapping("/api/v1")
public class Ass2_1 {

    ArrayList<Task> Tasks=new ArrayList<>();
    @GetMapping("/Tasker")
    public ArrayList<Task>  getTask() {
        return Tasks;

    }
    @PutMapping("/update/{index}")
    public ApiResponse updateUser(@PathVariable int index , @RequestBody Task Task ) {
        Tasks.set(index, Task);
        return new ApiResponse("Task Updateed!");
    }

    @DeleteMapping("/{index}")
    public ApiResponse  deletTask(@PathVariable int index ) {
        Tasks.remove(index);
        return new ApiResponse("Task deleted!");
    }
    public ApiResponse changeTask(@PathVariable boolean index){

    }
    public ApiResponse searchTask(@PathVariable int index){

    }


}
