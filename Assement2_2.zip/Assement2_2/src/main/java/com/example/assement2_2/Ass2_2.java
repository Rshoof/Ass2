package com.example.assement2_2;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController
@RequestMapping("/api/v1")
public class Ass2_2 {
    ArrayList<Customers> customer =new ArrayList<>();
    @GetMapping("/customer")
    public ArrayList <Customers> getCustomers(){
        return customer;
    }


    @PostMapping("/add")
    public ApiResponse addcustomer(@RequestBody Customers  customers ){
        customer.add(customers);
        return new ApiResponse("Customer addad!");
    }
    @PutMapping ("/update/{index}")
    public ApiResponse updateUser(@PathVariable int index , @RequestBody Customers  customers){
        customer.set(index,customers );
        return new  ApiResponse("Customer Updateed!");
    }
    @DeleteMapping ("/{index}")
    public ApiResponse  deletcustomer(@PathVariable int index ){
        customer.remove(index);
        return new ApiResponse ("Customer deleted!");
    }




}
